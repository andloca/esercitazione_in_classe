package esercitazione_java;

public abstract class Animali {
    String nome;
    int eta;
    public Animali(String n, int e){
        this.nome=n;
        this.eta=e;
    }
    public abstract void Verso();
    public abstract void muovi();
    public String getnome(){
        return this.nome;
    }
    public int geteta(){
        return this.eta;
    }
}