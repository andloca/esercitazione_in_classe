package esercitazione_java;

public class Leone extends Animali { 
    String n;
    int e;
    public Leone(String n,int e) {
        super(n, e);
    }
    @Override
    public void Verso() {
        System.out.println("Roarrr");
    }

    @Override
    public void muovi() {
        System.out.println("Il leone si è mosso");
    }
}