package esercitazione_java;

public class Scimmia extends Animali { 
    String n;
    int e;
    public Scimmia(String n,int e) {
        super(n, e);
    }
    @Override
    public void Verso() {
        System.out.println("uh uh ah ah");
    }
    @Override
    public void muovi() {
        System.out.println("Il leone si è mosso");
    }
}