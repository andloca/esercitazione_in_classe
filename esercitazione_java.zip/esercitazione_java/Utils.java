package esercitazione_java;

public class Utils {
    private Utils(){}

    public static void stampaInfo(Animali a) {
        System.out.println("INFO ANIMALE:");
        System.out.println("Tipo: " + a.getClass().getSimpleName());
        System.out.println("Nome: " + a.getnome());
        System.out.println("Età:  " + a.geteta() + " anni");
    }
}