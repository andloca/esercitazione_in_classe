package esercitazione_java;

import java.util.ArrayList;
import java.util.List;

public class Zoomain{
    public static void main(String[] args) {
        Leone leone1 = new Leone("Simba", 5);
        Leone leone2 = new Leone("Mufasa", 12);
        List<Animali> mioZoo = new ArrayList<>();
        mioZoo.add(leone1);
        mioZoo.add(leone2);
    
        for (Animali a : mioZoo) {
            Utils.stampaInfo(a);
            
            a.Verso();
            a.muovi();
            
            System.out.println();
        }
    }
}