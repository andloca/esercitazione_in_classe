Obiettivo
utilizzare classi astratte, classi concrete, metodi statici e package per organizzare il codice.
Scenario
Lo zoo ospita diversi tipi di animali  Ogni animale ha caratteristiche comuni ma comportamenti specifici.
1. Requisiti Tecnici
classe astratta Animale:
con attributi generali:
    nome
    età
metodi astratti:
    verso() 
    muovi().
Creare almeno due classi concrete:
    Leone:
    Scimmia: 
    che estendono Animale e implementano i metodi astratti.
Implementare una classe statica:
    ZooUtils 
    con metodi utili:
        stampaInfo(Animale a) che stampa nome, età e tipo di animale.
Utilizzare package per organizzare il codice:
zoo.animali → classi astratte e concrete
zoo.utils → classi statiche di supporto
2. Output e Comportamento
Creare un main class ZooMain:
istanzia più animali
li memorizza in una lista
utilizza i metodi di ZooUtils per stampare le informazioni.

Chiamare i metodi verso() e muovi() per ogni animale.

L’output deve essere leggibile e chiaro, mostrando la diversità dei comportamenti.




4. Consegna
Al termine dei lavori lo studente dovrà consegnare in un file PDF rinominato “Cognome Nome” il link alla repo github, screen di tutto il codice, della struttura del progetto e dell’output terminale.
